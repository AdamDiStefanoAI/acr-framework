package acr
escalate if {
    input.action.tool_name == "issue_refund"
}